install.packages("prophet")
install.packages("remotes")
remotes::install_github('facebook/prophet@*release', subdir='R')
library(prophet)
